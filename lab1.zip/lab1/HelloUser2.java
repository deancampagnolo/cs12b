//Dean Campagnolo
//dcampagn (1599389)
//12M
//This file prints a greeting to the user
class HelloUser2{

	public static void main(String[] args){
		System.out.println("Hello User (pt. 2)");

	}
}
