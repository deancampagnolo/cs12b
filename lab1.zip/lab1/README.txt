Dean Campagnolo
dcampagn (1599389)
12M
This file is the README and lists all of the files that I am turning in

Files in zip:
README.txt
log.txt
Makefile
Hello.jar
HelloUser.java
HelloUser2.java
